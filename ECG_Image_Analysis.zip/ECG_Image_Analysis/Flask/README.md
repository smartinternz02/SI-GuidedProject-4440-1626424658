# SPSGP-406-ECG-image-Analysis-for-Arrhythmia-Classification-Using-Deep-Learning
ECG image Analysis for Arrhythmia Classification Using Deep Learning

To run the application follow the steps:
1. set FLASK_APP=app.py
2. flask run
